#include<stdio.h>
#include<stdlib.h>
#include <windows.h>

#define DLLEXPORT __declspec(dllexport)

unsigned int F_GAP_MAX; //CTL1: ���նȣ��Ƽ�0x1000, ����ģʽΪ0x10000 
int F_ROUGH;            //CTL2: ����ģʽ 
int F_CLEAR;            //CTL4: ���ģʽ 

typedef struct FET{
    int head;
    int gap;
    int table_size;
    struct FET *next;
}FET, *PFET;

typedef struct one_tbl{
    int num;
    unsigned int* addr;
}one_tbl, *pone_tbl;

int comp(const void*a,const void*b){
	return *(unsigned int*)a>*(unsigned int*)b?1:-1;
}

int rule_match(char* bin, int pos, int off, int gap, int wnd){
	unsigned int max = 0;
	unsigned int min = 0xffffffff;
	unsigned int range;
	int tbl_item_sz = (gap+1)*4;
	int real_off  = pos + off*tbl_item_sz;
	int ptr;
	int i,j;
	unsigned int func_addr_list[wnd];
	for (i=0;i<wnd;i++){
		ptr = real_off + i*tbl_item_sz;
		func_addr_list[i] = *((unsigned int*)(bin+ptr));
		if (*((unsigned int*)(bin+ptr)) < min)
			min = *((int*)(bin+ptr));
		if (*((unsigned int*)(bin+ptr)) > max)
			max = *((unsigned int*)(bin+ptr));
	}
	for (i=0;i<wnd;i++){
		for (j=0;j<wnd;j++){
			if (func_addr_list[i] == func_addr_list[j] && i != j) return 0;
		}
	}
	range = max - min;
	if (range > F_GAP_MAX) return 0;
	for (i=0;i<wnd;i++){
		if (func_addr_list[i]%4 != 0 && func_addr_list[i]%2 != 1) return 0;
	}
	return 1;
}

PFET find_fet(char* bin, int start, int filesize, int wnd, int gap_max){
	int pos = start;
	int end = start + filesize;
	int gap,head,table_size,off;
	PFET fet_list  = (PFET)malloc(sizeof(FET));
	fet_list->next = NULL;
	PFET fet_l_ptr = fet_list;
	while (pos >= start && pos < end){
		for (gap=0;gap<=gap_max;gap++){
			off = 0;
			if (rule_match(bin,pos,off,gap,wnd)){
				head       = pos;
				table_size = wnd;
				off       += wnd;
				while (rule_match(bin,pos,off,gap,wnd)){
					table_size += wnd;
					off        += wnd;
				}
				if (F_ROUGH == 1) pos += table_size*(gap + 1)*4 - 1; //CTL2.1: ����ģʽ 
				fet_l_ptr->next       = (PFET)malloc(sizeof(FET));
				fet_l_ptr             = fet_l_ptr->next;
				fet_l_ptr->head       = head;
				fet_l_ptr->gap        = gap;
				fet_l_ptr->table_size = table_size;
				fet_l_ptr->next       = NULL;
				if (F_ROUGH == 1) break; //CTL2.2: ����ģʽ 
			}
		}
		pos++;
	}
	return fet_list;
}

void dbmfet(char* bin, int filesize, pone_tbl tbl, float T){
	int n = tbl->num;
	unsigned int* tb = tbl->addr;
	unsigned int guess_base;
	int i,start;
	int thumb=0,arm=0;
	
	int debug=0;
	
	if(tb[n-1]<(unsigned int)filesize) {
		start = 0;
	}else{
		start = tb[n-1]-filesize;
	}
	for (guess_base=start;guess_base<=tb[0];guess_base++){  //CTL3: ���ϵ�ģʽ 
		if (guess_base%0x1000 == 0  ||  F_CLEAR ==0){  //CTL4: ���ģʽ 
			for (i=0;i<n;i++){
				if (tb[i]%2 == 1) {
					if (bin[tb[i]-guess_base] == (char)0xb5) thumb++;
				}else{
					if (bin[tb[i]-guess_base+2] == (char)0x2d && bin[tb[i]-guess_base+3] == (char)0xe9) arm++;
				}
			}
			if (((float)arm+(float)thumb)/(float)n > T) printf("OUTPUT:  %08x========%f\n" ,guess_base, ((float)arm+(float)thumb)/(float)n);
			thumb=0,arm=0;
    	}
	}
}

void dbmfet_boot(char* bin, int filesize, pone_tbl tbl, float T, unsigned int boot_pc){
	int n = tbl->num;
	unsigned int* tb = tbl->addr;
	unsigned int guess_base;
	int i,start;
	int thumb=0,arm=0;
	
	int debug=0;
	
	if(tb[n-1]<(unsigned int)filesize) {
		start = 0;
	}else{
		start = tb[n-1]-filesize;
	}
	for (guess_base=start;guess_base<=(boot_pc<=tb[0]?boot_pc:tb[0]);guess_base++){  //CTL3: �ϵ�ģʽ 
		if (guess_base%0x1000 == 0  ||  F_CLEAR ==0){  //CTL4: ���ģʽ 
			for (i=0;i<n;i++){
				if (tb[i]%2 == 1) {
					if (bin[tb[i]-guess_base] == (char)0xb5) thumb++;
				}else{
					if (bin[tb[i]-guess_base+2] == (char)0x2d && bin[tb[i]-guess_base+3] == (char)0xe9) arm++;
				}
			}
			if (((float)arm+(float)thumb)/(float)n > T) printf("OUTPUT:  %08x========%f\n" ,guess_base, ((float)arm+(float)thumb)/(float)n);
			thumb=0,arm=0;
    	}
	}
}

pone_tbl get_tbl(char* bin, PFET p_fet){
	int i,index = 0;
	int tbl_item_sz = (p_fet->gap+1)*4;
	int off;
	int n = 1;
	unsigned int* tbl = (unsigned int*)malloc(sizeof(unsigned int)*(p_fet->table_size));
	for (i=0;i<p_fet->table_size;i++){
		off    = p_fet->head + i*tbl_item_sz;
		tbl[i] = *((unsigned int*)(bin+off));
																																		//printf("debug:%p###%p\n" , off, tbl[i]);
	}
	qsort(tbl,p_fet->table_size,sizeof(unsigned int),comp);
	for (i=1;i<p_fet->table_size;i++) {
		if(tbl[i] != tbl[i-1]) n++;
	}
	unsigned int* tbl_o = (unsigned int*)malloc(sizeof(unsigned int)*n);
	tbl_o[0] = tbl[0];																													//printf("#####%p\n", tbl[0]);
	for (i=1;i<p_fet->table_size;i++) {
		if(tbl[i] != tbl[i-1]){
			tbl_o[++index] = tbl[i];
																																		//printf("#####%p\n", tbl[i]);
		}
	}
	free(tbl);
	pone_tbl r = (pone_tbl)malloc(sizeof(one_tbl));
	r->num  = n;
	r->addr = tbl_o;
	return r;
}

DLLEXPORT void find_load_base(char *filename, int wnd, int gap, float T, unsigned int f_gap_m, int f_rough, unsigned int boot, int f_clear){
	F_GAP_MAX = f_gap_m;
	F_ROUGH   = f_rough;
	F_CLEAR   = f_clear;
	FILE* fid = fopen(filename,"rb");
	fseek (fid , 0 , SEEK_END);  
    long size = ftell(fid); 
    rewind (fid); 
	char *bin = (char *)malloc(size+1);
    fread(bin,1,size,fid);
	PFET fet = find_fet(bin,0,size,wnd,gap); //CTL5: ���� �� gap 
    PFET ptr = fet->next;
    pone_tbl p_tbl;
    int i=0,j;
    do{
																																		//printf("head:%p  gap:%d  tableSize:%d    ", ptr->head, ptr->gap, ptr->table_size);
    																																	//printf("%d/2266\n",i);
    																																	//system("pause");
    	p_tbl = get_tbl(bin,ptr);
    	if (boot == 0)
			dbmfet(bin,size,p_tbl,T); //CTL6: ��ֵ 
		else
			dbmfet_boot(bin,size,p_tbl,T,boot); //CTL6: ��ֵ 
    	free(p_tbl->addr);
		free(p_tbl);
		ptr = ptr->next;
    	i++;
	}while(ptr);
	printf("%d\n", i);
	puts("end");
}

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	switch(fdwReason)
	{
		case DLL_PROCESS_ATTACH:
		{
			break;
		}
		case DLL_PROCESS_DETACH:
		{
			break;
		}
		case DLL_THREAD_ATTACH:
		{
			break;
		}
		case DLL_THREAD_DETACH:
		{
			break;
		}
	}
	
	/* Return TRUE on success, FALSE on failure */
	return TRUE;
}
