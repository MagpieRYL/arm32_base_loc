import arm32_base_loc_x64

arm32_base_loc_x64.find_load_base("sony",3,3,0.6,0x1000,0,0x80BF029,1)