from ctypes import *

def find_load_base(filename, wnd, gap, T, f_gap_m, f_rough, boot, f_clear):
    pDll = CDLL("arm32_base_loc_x64.dll")
    pDll.find_load_base(filename,wnd,gap,c_float(T),f_gap_m,f_rough,c_uint(boot),f_clear)